<!DOCTYPE html>
<html>
 <head>
  <meta charset="UTF-8">
  <style>
   a:link {color:#34DE01;text-decoration:none;}
   a:hover {color:#002C59;text-decoration:none;}
   a:visited {color:#34DE01;text-decoration:none;}
  </style>
  <title>
   Bienvenido a tu hosting! Powered by Netuy®
  </title>
 </head>
 <body>
  <br><br>
  <p style="text-align:center; font-family: Arial; color:#002C59; font-size: 150%;">
  <a href="https://www.netuy.net"><img src="http://www.netuy.net/banner_hosting_uruguay/logo.esqueleto.cpanel.jpg" style="text-align:center" alt="Netuy" width="40%"></a>
  <br><br><br>
  <b>Felicitaciones, ya puedes cargar tu sitio web!
  <br><br>
  <a href="https://www.netuy.net">Netuy®</a> es Hosting en Uruguay.</b>
  </p>
 </body>
