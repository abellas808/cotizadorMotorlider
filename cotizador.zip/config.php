<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'marcos2022_usr_api');
define('DB_PASS', '_eT4AjJ79~tX]*h)J5');
define('DB_NAME', 'marcos2022_api');
?>